import BackNavE from "@/components/exam/BackNavExam";
import Link from "next/link";

export default function Exam() {

    return (
        <main>
            <BackNavE />

            <div className="m-6 flex flex-col gap-4 ">
                <Link href="/course/exam/doexam" className="flex flex-col items-center justify-center gap-2 p-10 bg-emerald-700 rounded-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1" stroke="currentColor" className="size-9 text-white">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L6.832 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125" />
                    </svg>
                    <p className="text-white">ทำข้อสอบ</p>
                </Link>
                <Link href="/course/exam/photoexam" className="flex flex-col items-center justify-center gap-2 p-10 rounded-lg border border-zinc-300">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1" stroke="currentColor" className="size-9 text-emerald-700">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                    </svg>

                    <p className="text-emerald-700">ถ่ายกระดาษคำตอบ</p>
                </Link>
            </div>
        </main>
    );
}